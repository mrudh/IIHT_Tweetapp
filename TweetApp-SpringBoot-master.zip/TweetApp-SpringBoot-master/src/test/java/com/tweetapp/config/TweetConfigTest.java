package com.tweetapp.config;

public class TweetConfigTest {

}
